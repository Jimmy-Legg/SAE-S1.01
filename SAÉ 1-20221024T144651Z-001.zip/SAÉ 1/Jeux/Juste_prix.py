import os
import time



    

def bornes():
    global maxi,mini

    os.system("cls")
    maxi = str(input('Nombre max que lon peut rentrer : '))


    while(not maxi.isdigit()):
        print("Valeur impossible")
        maxi = str(input('Nombre max que lon peut rentrer : '))
        os.system("pause")


    mini = str(input('Nombre min que lon peut rentrer : '))
    while(not mini.isdigit()):
        print("Valeur impossible")
        mini = str(input('Nombre min que lon peut rentrer : '))
        os.system("pause")
    menu()

def jeux():
    global dansvar,temps1,temps2

    dansvar = True

    j1_name : str
    j2_name : str

    B  = '\033[94m' # blue
    W  = '\033[0m'  # white (normal)
    R  = '\033[91m' # r
    nombre : str
    trouve : bool
    partiefini : bool
    nombre_a_trouver : str

    
    os.system("cls")
    j1_name = "Nathan"
    #str(input(B + "Joueur 1" + W + ", quel est votre nom ? "))
    j2_name = "Jimmy"
    #str(input(R + "Joueur 2" + W + ", quel est votre nom ? "))
    nombre = 0
    print("A " + B + j1_name + W + " de choisir un nombre")
    os.system("pause")
    while True:
        nombre_a_trouver = str(input(B + j1_name + W + "  choisissez un nombre entre " + str(mini) + " et " + str(maxi) + " : "))
        if(not nombre_a_trouver.isdigit()):print("Valeur impossible")
        elif(int(nombre_a_trouver) < int(mini) or int(nombre_a_trouver) > int(maxi)):print("Valeur impossible")
        else:break
        

    partiefini = False
    os.system("cls")
    

    while partiefini == False :

        trouve = False
        print("A " + R + j2_name + W + " de trouver")
        os.system("pause")
        os.system("cls")

        temps1 = time.time()
        while trouve != True :
            

            if int(nombre) == int(nombre_a_trouver):
                trouve = True
                temps1 = time.time()-temps1
                break
            if int(nombre) < int(nombre_a_trouver):
                
                while True:
                    os.system("cls")

                    print(R +j2_name + W + " : ")
                    print("Nombre entre " + str(mini) + " et " + str(maxi) + " : ")
                    nombre = int(input("nombre plus grand que " + str(nombre) + " : "))

                    if(not str(nombre).isdigit()):print("Valeur impossible")
                    elif(int(nombre) < int(mini) or int(nombre) > int(maxi)):print("Valeur impossible")
                    else:break
                os.system("cls")
            if int(nombre) > int(nombre_a_trouver):
                
                while True:
                    os.system("cls")
                    print(R +j2_name + W + " : ")
                    print("nombre entre " + str(mini) + " et " + str(maxi) + " : ")
                    nombre = int(input("nombre plus petit que " + str(nombre) + " : "))

                    if(not str(nombre).isdigit()):print("Valeur impossible")
                    elif(int(nombre) < int(mini) or int(nombre) > int(maxi)):print("Valeur impossible")
                    else:break
                    
                os.system("cls")
            print("A " + R + j2_name + W + " de choisir un nombre")
            os.system("pause")


            while True:
                nombre_a_trouver = str(input(R + j2_name + W + "  choisissez un nombre entre " + str(mini) + " et " + str(maxi) + " : "))
                if(not str(nombre_a_trouver).isdigit()):print("Valeur impossible")
                elif(int(nombre_a_trouver) < int(mini) or int(nombre_a_trouver) > int(maxi)):print("Valeur impossible")
                else:break
                
            os.system("cls")

            nombre = 0
            trouve =False
            
            
            
            print("A " + B + j1_name + W + " de trouver")
            os.system("pause")
            os.system("cls")
            temps2 = time.time()
            while trouve != True :
                
                if int(nombre) == int(nombre_a_trouver):
                    trouve = True
                    temps2 = time.time()-temps2
                    partiefini = True
                    break

                if int(nombre) < int(nombre_a_trouver):
                    
                    while True:
                        print(B +j1_name + W + " : ")
                        print("nombre entre " + mini + " et " + maxi + " : ")
                        nombre = str(input("nombre plus grand que " + str(nombre) + " : "))

                        if(not str(nombre).isdigit()):print("Valeur impossible")
                        elif(int(nombre) < int(mini) or int(nombre) > int(maxi)):print("Valeur impossible")
                        else:break
                    os.system("cls")    
                if int(nombre) > int(nombre_a_trouver):
                    
                    while True:
                        print(B +j1_name + W + " : ")
                        print("nombre entre " + str(mini) + " et " + str(maxi) + " : ")
                        nombre = str(input("nombre plus petit que " + str(maxi) + " : "))

                        if(not str(nombre).isdigit()):print("Valeur impossible")
                        elif(int(nombre) < int(mini) or int(nombre) > int(maxi)):print("Valeur impossible")
                        else:break
                    os.system("cls")
                
        partiefini = True
    while True:

        if temps1 < temps2 :
            print("le gangnant est : " + B + j1_name)
            return j1_name
        elif temps1 > temps2 :
            print("le gangnant est : "+ R + j2_name)
            return j2_name
        elif temps1 == temps2:
            print("égalité")
        os.system("pause")
        
    

    
def menu():
    global mini,maxi
    os.system("cls")
    vari :str
    print("------------------------------------------")
    print('')
    print("1. Play")
    print("2. choisir les bornes min et max de jeu")
    print('')
    print("------------------------------------------")
    vari = 4
    while True:
        vari = str(input("Choix :"))
        if(not str(vari).isdigit()):print("Valeur impossibled")
        elif(int(vari) < 1 or int(vari) > 2):print("Valeur impossible")
        else:break
    if int(vari) == 1:
        if maxi == 0 and mini == 0:
            print("définissez d'abord les bornes de jeu")
            os.system("pause")
            menu()            
        elif maxi != 0 and mini != 0:
            jeux()
    elif int(vari) == 2:
        bornes()
    

if __name__ == '__main__' :
    dansvar : bool
    vari : str
    maxi : str 
    mini : str
    maxi=0
    mini=0
    temps1 : float
    temps2 : float

    menu()